Start the simulator with
start_simulator.bat

Registered HTTP URLs
~~~~~~~~~~~~~~~~~~~~

Miele@home Gateway Root URL
http://<gateway_ip>:<http_port>/

Miele@home Gateway Web Administration Application
http://<gateway_ip>:<http_port>/gwadmin

Miele@home Homebus
http://<gateway_ip>:<http_port>/homebus

Miele@home Homebus Test Tool
http://<gateway_ip>:<http_port>/homebustool

Miele@Home Minibrowser
http://<gateway_ip>:<http_port>/miele

Valid Credentials
~~~~~~~~~~~~~~~~~

username: mymiele
password: mymiele